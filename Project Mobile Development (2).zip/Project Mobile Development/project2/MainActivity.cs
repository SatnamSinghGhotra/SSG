﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using Android.Runtime;
using Android.Widget;
using System;

namespace project2
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);
            EditText NumberText = FindViewById<EditText>(Resource.Id.NumberText);
            Button translateButton = FindViewById<Button>(Resource.Id.TranslateButton);
            // TextView translatedPhoneWord = FindViewById<TextView>(Resource.Id.TranslatedPhoneWord);
            // Button translationHistoryButton = FindViewById<Button>(Resource.Id.TranslationHistoryButton);
            // Add code to translate number
            string translatedNumber = string.Empty;

            Button button = FindViewById<Button>(Resource.Id.TranslateBinary);
            int i;
            int n = Resource.Id.TranslateBinary;
            int[] a = new int[10];
            button.Click += delegate
            {
                for (i = 0; n > 0; i++)
                {
                    a[i] = n % 2;
                    n = n / 2;
                }
                for (i = i - 1; i >= 0; i--)
                {

                    button.Text = string.Format("{0}    Binar number is ", +a[i]);
                }
                Button button1 = FindViewById<Button>(Resource.Id.TranslateButton1);
                int[] octalVal = new int[10];
                int j = 0;
                int quot = Resource.Id.TranslateBinary;
                button.Click += delegate
                {
                    while (quot != 0)
                    {
                        octalVal[j++] = quot % 8;
                        quot = quot / 8;
                    }
                };
                button1.Text = string.Format("{0}    Octal number is ", +quot);


                Button button3 = FindViewById<Button>(Resource.Id.TranslateButton2);
                int decn, q, dn = 0, m, l;
                int tmp;
                int s;


                decn = Convert.ToInt32(Console.ReadLine());
                q = decn;
                for (l = q; l > 0; l = l / 16)
                {
                    tmp = l % 16;

                    if (tmp < 10)
                        tmp = tmp + 48;
                    else
                        tmp = tmp + 55;
                    dn = dn * 100 + tmp;
                }
                for (m = dn; m > 0; m = m / 100)
                {
                    s = m % 100;

                    button3.Text = string.Format("{0}", (char)s);
                }
            };
            Button button4 = FindViewById<Button>(Resource.Id.TranslateSquare);

            button.Click += delegate
            {
                float sqr;
                float sqrans = sqr * sqr;

                button4.Text = string.Format("{0}    Square is is ", +sqrans);
            };
            Button button5 = FindViewById<Button>(Resource.Id.TranslateCube);

            button.Click += delegate
            {
                float c1;
                float canswer = c1 * c1 * c1;

                button4.Text = string.Format("{0}    Square is is ", +canswer);
            };
            Button button6 = FindViewById<Button>(Resource.Id.RateApp);

            button.Click += delegate
            {
                
                };

            };
        }
    }
}